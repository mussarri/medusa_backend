export type EventType = {
  id: string
  type: string
  time: Date
}
